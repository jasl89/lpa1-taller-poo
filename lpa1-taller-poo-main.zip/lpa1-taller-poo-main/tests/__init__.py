# necesario para que Python trate el directorio tests como un paquete

